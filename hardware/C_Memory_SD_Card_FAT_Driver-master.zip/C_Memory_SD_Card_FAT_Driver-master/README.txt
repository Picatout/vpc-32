
######################################################################
##### Open sourced by IBEX, an electronic product design company #####
#####    based in South East England.  http://www.ibexuk.com     #####
######################################################################

This project was previously available from our http://www.embedded-code.com source code store (owned by IBEX UK Ltd) and is a fully packaged and documented project.  After several years selling these source code projects to developers we took the decision to finally open source all of the projects hosted on the site.

The projects original page on the embedded-code.com web site, which includes a detailed technical manual, can be found at: http://www.embedded-code.com/source-code/memory/secure-digital-mmc-memory-cards/secure-digital-mmc-memory-card-fat16-fat32-driver

